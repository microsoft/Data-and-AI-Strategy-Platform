#
# Copyright (c) Microsoft. All rights reserved.
# Licensed under the MIT license. See LICENSE file in the project.
#


"""
This script initializes a SparkSession and SparkContext, and creates a SparkConf object. 
The SparkSession is created using either an active SparkSession or a new SparkSession builder.
The SparkContext is retrieved using the getOrCreate method.
Finally, the SparkConf object is created using the getConf method on the SparkContext object.
"""

# Import required modules
from pyspark import SparkConf, SparkContext
from pyspark.sql import SparkSession


# Initialize SparkSession and SparkContext
config = SparkConf().setAll([("spark.executor.allowSparkContext", "true"), ("spark.port.maxRetries", "200")])

spark: SparkSession = (
    SparkSession.builder.appName("Transparency Engine")
    .enableHiveSupport()
    .config(conf=config)
    .getOrCreate()
)

sc: SparkContext = spark.sparkContext

# Create SparkConf object
conf: SparkConf = sc.getConf()
